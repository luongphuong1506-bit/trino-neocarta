"""Dataplex schema sub-connector."""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING

from ...._logging import log_transform_counts
from ....errors import StateError
from ....ingest.rdbms import Neo4jRDBMSLoader
from .extract import DataplexSchemaExtractor
from .transform import DataplexSchemaTransformer

if TYPE_CHECKING:
    from typing import Self

    from google.cloud import dataplex_v1
    from neo4j import Driver

logger = logging.getLogger(__name__)

# (human label, transformer attribute) pairs logged at the end of transform().
_TRANSFORM_COUNTS = (
    ("databases", "database_nodes"),
    ("schemas", "schema_nodes"),
    ("tables", "table_nodes"),
    ("columns", "column_nodes"),
)


class DataplexSchemaConnector:
    """
    Connector for BigQuery schema metadata extracted via Dataplex Universal Catalog.

    Produces Database/Schema/Table/Column nodes and their HAS_* edges.
    Pairs with :class:`DataplexGlossaryConnector` (loaded after) to attach
    business-term tags to schema entities.

    Parameters
    ----------
    catalog_client : dataplex_v1.CatalogServiceClient
        The Dataplex Catalog client.
    project_id : str
        The GCP project ID.
    project_number : str
        The GCP project number.
    dataplex_location : str
        The Dataplex location (e.g. ``us-central1`` or ``us``).
    neo4j_driver : Driver
        Neo4j driver instance.
    database_name : str, default "neo4j"
        Target Neo4j database name.
    """

    def __init__(
        self,
        catalog_client: dataplex_v1.CatalogServiceClient,
        project_id: str,
        project_number: str,
        dataplex_location: str,
        neo4j_driver: Driver,
        database_name: str = "neo4j",
    ) -> None:
        """Initialize the Dataplex schema connector."""
        self.catalog_client = catalog_client
        self.project_id = project_id
        self.project_number = project_number
        self.dataplex_location = dataplex_location
        self.neo4j_driver = neo4j_driver
        self.database_name = database_name

        self.extractor = DataplexSchemaExtractor(
            catalog_client, project_id, project_number, dataplex_location
        )
        self.transformer = DataplexSchemaTransformer()
        self.loader = Neo4jRDBMSLoader(neo4j_driver, database_name)
        self._extracted = False
        self._transformed = False

    def close(self) -> None:
        """No connector-owned resources to release; the injected Neo4j driver is the caller's."""

    def __enter__(self) -> Self:
        """Return self for use as a context manager."""
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        """Release owned resources on context-manager exit."""
        self.close()

    def extract(self, dataset_id: str) -> None:
        """
        Extract BigQuery catalog metadata for a single dataset into the cache.

        Parameters
        ----------
        dataset_id : str
            The BigQuery dataset ID to extract.
        """
        logger.info("Extracting Dataplex schema metadata...")
        self._extracted = False
        self._transformed = False
        self.extractor.extract(dataset_id=dataset_id)
        self._extracted = True

    def transform(self) -> None:
        """
        Transform cached metadata into Database/Schema/Table/Column nodes + HAS_* edges.

        Raises:
        ------
        StateError
            If called before :meth:`extract`.
        """
        if not self._extracted:
            raise StateError(
                "DataplexSchemaConnector.transform() called before extract().",
                suggestion="Call connector.extract(dataset_id=...) before connector.transform().",
            )
        self._transformed = False
        logger.info("Transforming Dataplex schema metadata...")
        e = self.extractor
        t = self.transformer

        t.transform_to_database_nodes(e.database_info)
        t.transform_to_schema_nodes(e.schema_info)
        t.transform_to_table_nodes(e.table_info)
        t.transform_to_column_nodes(e.column_info)

        t.transform_to_has_schema_relationships(e.schema_info)
        t.transform_to_has_table_relationships(e.table_info)
        t.transform_to_has_column_relationships(e.column_info)
        log_transform_counts(logger, t, _TRANSFORM_COUNTS)
        self._transformed = True

    def load(self) -> None:
        """
        Load transformed nodes and relationships into Neo4j.

        Raises:
        ------
        StateError
            If called before :meth:`transform`.
        """
        if not self._transformed:
            raise StateError(
                "DataplexSchemaConnector.load() called before transform(); "
                "call .transform() first.",
                suggestion="Call connector.extract() and connector.transform() first.",
            )
        t = self.transformer

        logger.info("Loading Dataplex schema metadata into Neo4j...")
        self.loader.load_database_nodes(t.database_nodes)
        self.loader.load_schema_nodes(t.schema_nodes)
        self.loader.load_table_nodes(t.table_nodes)
        self.loader.load_column_nodes(
            t.column_nodes, properties_list=["name", "description", "type"]
        )

        self.loader.load_has_schema_relationships(t.has_schema_relationships)
        self.loader.load_has_table_relationships(t.has_table_relationships)
        self.loader.load_has_column_relationships(t.has_column_relationships)

    def ingest(self, dataset_id: str) -> None:
        """
        Run the Dataplex schema connector (extract → transform → load).

        Parameters
        ----------
        dataset_id : str
            The BigQuery dataset ID to ingest.
        """
        self.extract(dataset_id)
        self.transform()
        self.load()
        self.loader.upsert_neocarta_graph_node()
        logger.info("Recorded neocarta graph metadata")
        logger.info("Dataplex schema connector completed successfully")

    def run(self, dataset_id: str) -> None:
        """
        Run the Dataplex schema connector.

        .. deprecated::
            Use :meth:`ingest` instead. ``run`` will be removed in a future release.
        """
        warnings.warn(
            "DataplexSchemaConnector.run() is deprecated; "
            "use DataplexSchemaConnector.ingest() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.ingest(dataset_id)
