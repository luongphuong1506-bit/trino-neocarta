"""Graph data model components."""
